def greet(name):
    return f"مرحباً يا {name}! كيف أساعدك اليوم؟"

if __name__ == "__main__":
    user_name = input("ادخل اسمك: ")
    print(greet(user_name))
